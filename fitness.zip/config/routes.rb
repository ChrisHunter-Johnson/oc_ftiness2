Rails.application.routes.draw do

  devise_for :users
  devise_for :models
 get 'site/home'

 get '/activities/index', to: 'activities#index'

 get '/about', to: 'pages#about'





  resources :activities
  resources :categories
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
 root 'site#home'
end
