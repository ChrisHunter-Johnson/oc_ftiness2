


  $(function() {
    $('#activity_date').datepicker({
            dateFormat: 'dd-M-yy',
            changeMonth: true,
            changeYear: true});
  });

 //$(function() {
//   $('#activity_duration').timepicker()};
 //    'option', { 'minTime': '4:00am', 'timeFormat': 'H:i' });
